<?
$arModuleVersion = array(
	"VERSION" => "1.3.62",
	"VERSION_DATE" => "2023-05-25 14:01:14"
);
?>