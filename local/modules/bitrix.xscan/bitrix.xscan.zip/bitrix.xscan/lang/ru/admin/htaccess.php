<?
$MESS["BITRIX_XSCAN_NAME"] = "Файл";
$MESS["BITRIX_XSCAN_SIZE"] = "Размер";
$MESS["BITRIX_XSCAN_M_DATE"] = "Дата модификации";
$MESS["BITRIX_XSCAN_C_DATE"] = "Дата создания";
$MESS["BITRIX_XSCAN_STATUS"] = "Статус";
$MESS["BITRIX_XSCAN_RESCAN"] = "Повторная проверка";
$MESS["BITRIX_XSCAN_RENEW"] = "Удалить всё и установить минимальный набор";
$MESS["BITRIX_XSCAN_HT_ALERT"] = "Обнаружены опасные htaccess файлы";
$MESS["BITRIX_XSCAN_HT_OK"] = "Опасных htaccess не обнаружено";
$MESS["BITRIX_XSCAN_HTACCESS"] = "Проверка файлов .htaccess";

?>