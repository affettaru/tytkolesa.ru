<?
$MESS["BITRIX_XSCAN_SEARCH"] = "Поиск троянов";
$MESS["BITRIX_XSCAN_NOT_FOUND"] = "Файл не найден в списке троянов: ";
$MESS["BITRIX_XSCAN_RENAMED"] = "Файл переименован: ";
$MESS["BITRIX_XSCAN_ERR_RENAME"] = "Ошибка переименования: ";
$MESS["BITRIX_XSCAN_FILE_CONT"] = "Содержимое файла ";
$MESS["BITRIX_XSCAN_FILE_NOT_FOUND"] = "Файл не найден: ";
$MESS["BITRIX_XSCAN_IN_PROGRESS"] = "Идёт поиск";
$MESS["BITRIX_XSCAN_CURRENT_FILE"] = "Текущий файл";
$MESS["BITRIX_XSCAN_COMPLETED"] = "Поиск завершен. Подозрительные файлы не найдены";
$MESS["BITRIX_XSCAN_COMPLETED_FOUND"] = "Найдены подозрительные файлы";
$MESS["BITRIX_XSCAN_START_SCAN"] = "Начать поиск";
$MESS["BITRIX_XSCAN_NAME"] = "Имя";
$MESS["BITRIX_XSCAN_TYPE"] = "Тип опасности";
$MESS["BITRIX_XSCAN_SIZE"] = "Размер";
$MESS["BITRIX_XSCAN_SCORE"] = "Оценка";
$MESS["BITRIX_XSCAN_M_DATE"] = "Дата модификации";
$MESS["BITRIX_XSCAN_SRC"] = "просмотр исходного текста";
$MESS["BITRIX_XSCAN_WARN"] = "Если файл используется на сайте, переименование файла приведет к неработоспособности сайта.\\nПродолжить?";
$MESS["BITRIX_XSCAN_WARN_RELEASE"] = "Вы действительно хотите восставновить файл?";
$MESS["BITRIX_XSCAN_QUESTION"] = "Переименовать файл";
$MESS["BITRIX_XSCAN_KARANTIN"] = "Карантин";
$MESS["BITRIX_XSCAN_ISOLATE"] = "В Карантин";
$MESS["BITRIX_XSCAN_UNISOLATE"] = "Востановить";
$MESS["BITRIX_XSCAN_ACTIONS"] = "Действия";
$MESS["BITRIX_XSCAN_WATCH_EVENT"] = "Просмотр";

$MESS["BITRIX_XSCAN_POCEMU_VYBRAN_ETOT_F"] = "Почему выбран этот файл? Условие PHP:";
$MESS["BITRIX_XSCAN_FAYL"] = "Файл ";
$MESS["BITRIX_XSCAN_PODOZRITELQNYY_KOD"] = "Подозрительный код";
$MESS["BITRIX_XSCAN_NACALQNYY_PUTQ_NE_NA"] = "Начальный путь не найден";
$MESS["BITRIX_XSCAN_NACALQNYY_PUTQ"] = "Начальный путь: ";
$MESS["BITRIX_XSCAN_SESSIA_USTARELA_OBN"] = "Сессия устарела. Обновите страницу";
$MESS["BITRIX_XSCAN_FAYL_NE_VYGLADIT_POD"] = "Файл не выглядит подозрительным";

$MESS["BITRIX_XSCAN_COMPLETED_EVENTS_FOUND"] = "Найдены подозрительные события/агенты";
$MESS["BITRIX_XSCAN_EVENT"] = "подозрительное событие/агент";
$MESS["BITRIX_XSCAN_EVENT_ID"] = "ID";
$MESS["BITRIX_XSCAN_EVENT_EDIT"] = "просмотр";
$MESS["BITRIX_XSCAN_AGENT"] = "agent";


?>