<?
$MESS["BITRIX_XSCAN_SYSTEM"] = "Cостояние системы";
$MESS["BITRIX_XSCAN_SYSTEM_INFO"] =  <<<'html'

<div class="adm-info-message-wrap adm-info-message-red">
    <div class="adm-info-message">
        <div class="adm-info-message-title">Помимо поиска троянов так же следует:</div>
        <ul>
            <li> Проверить нет ли запущенных подозрительных процессов на сервере </li> 
            <li> Проверить нет ли посторонних заданий в crontab</li> 
            <li> Нет ли посторонних ssh ключей</li> 
        </ul>
        <div class="adm-info-message-icon"></div>
    </div>
</div>

html;

?>