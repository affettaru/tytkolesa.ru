<?
$MESS["BITRIX_XSCAN_SEARCH"] = "Поиск";
$MESS["BITRIX_XSCAN_SEARCH_FORK"] = "Поиск";
$MESS["BITRIX_XSCAN_DATA_IZMENENIA_JURNA"] = "Дата изменения журнала: ";
$MESS["BITRIX_XSCAN_SEARCH_OLD"] = "Поиск (old)";
$MESS["BITRIX_XSCAN_HELP"] = "Справка";
$MESS["BITRIX_XSCAN_SYSTEM"] = "Операционная система";
$MESS["BITRIX_XSCAN_HTACCESS"] = "Проверка htaccess";

?>