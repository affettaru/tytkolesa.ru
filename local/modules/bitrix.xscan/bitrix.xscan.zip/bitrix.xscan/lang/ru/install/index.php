<?
$MESS["bitrix.xscan_MODULE_NAME"] = "Поиск троянов";
$MESS["bitrix.xscan_MODULE_DESC"] = "Модуль поможет программистам найти трояны на сайте. Он сканирует весь сайт и сохраняет подозрительные файлы в список. Их можно посмотреть и поместить в карантин, где трояны не будут опасны.

Подробное описание в блоге: http://dev.1c-bitrix.ru/community/blogs/howto/antihack.php

Ошибки и пожелания по улучшению присылайте нам на почту regexp-challenge@bitrix.ru";
$MESS["bitrix.xscan_PARTNER_NAME"] = "Битрикс";
$MESS["bitrix.xscan_PARTNER_URI"] = "http://www.1c-bitrix.ru";
?>