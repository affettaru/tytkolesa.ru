<?php declare(strict_types=1);

namespace PhpParser\Node;

abstract class Scalar extends Expr
{
}
